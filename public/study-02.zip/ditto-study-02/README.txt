Ditto / Study 02 — Explicit bursts

All images are synthetic technical patterns, with invented IDs and camera details.
Extract this archive and choose the ditto-study-02 parent folder once.

Expected: 12 files, 1 exact-copy group, 2 burst ID groups.
Burst A: 5 files / 4 different contents; Burst B: 2 files / 2 contents.
Different contents are NOT a count of original frames (A includes an export).
Coverage: 8 identified, 2 with no ID found, 1 unsupported, 1 invalid.

The A and B groups span two capture seconds but remain separate from each other.
The missing-time A file still joins via its ID. Its chronological order is unknown.
The preserved export joins A; the stripped export stays out even with matching time.
Sequence-only, zero UUID, and Live Photo ID files never create a burst group.
The singleton has an ID, but no other selected file sharing it.
Study 01's same-second candidates may contain A and B together; that view is unchanged.

Export burst notes includes all 12 files and their read status, including exclusions.
It contains file paths, hashes, camera details, and any recorded IDs.
These constructed examples validate rules, NOT real Apple Photos export behavior.
The next observation is whether IDs survive real original/export workflows.
