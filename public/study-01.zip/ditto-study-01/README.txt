DITTO — STUDY 01: VERSIONS

These are synthetic technical test patterns, not real photographs.
Extract this archive, then choose the extracted ditto-study-01 folder once.
Do not separately select its subfolders.

Expected results: 11 photos checked, 1 exact-copy group, 4 possibly-related groups.
10 files have usable capture times. color-study-no-tags.jpg has no capture time.

Try each candidate and mark your assessment:
1. Color study (10:20 camera time): original + exact backup + crop + small export.
   All four files are versions of the same source pattern. Three different contents.
2. Burst (10:30): two distinct images with fractional seconds .100 and .250.
   Ditto should display a fractional-time conflict, not confirm a common origin.
3. Camera conflict (10:40): different images from different synthetic cameras.
   Ditto should display conflicting camera models and serial numbers.
4. Time only (11:00): different images sharing only a whole-second clock reading.
   Ditto should label these weak candidates and show missing evidence.

The stripped-metadata export is related to the first pattern but stays out of
possible groups. This is an intentional false negative illustrating the limit.

GPS coordinates are synthetic metadata near central Seattle, not a private
location. Camera names and serials are invented fixture values.

Export study notes to retain assessments and metadata evidence. All assessments
are session-only; they do not change automatic grouping or any original file.
